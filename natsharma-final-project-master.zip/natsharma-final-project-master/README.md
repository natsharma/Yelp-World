# natsharma-ait-primer
Final Project Name: Around the World

Description: The user can enter in their name and a list of places they have been in the world (countries only). And when they press enter, photos of those places appear. Photos will be queried using URLs. The photo of the queried place is retrieved and the user can add descriptive tags to it. 
